export function validUser() {
    return {
        "display_name": "Jo Franchetti",
        "external_urls": {
            "spotify": "https://open.spotify.com/user/11124066204"
        },
        "followers": {
            "href": null,
            "total": 30
        },
        "href": "https://api.spotify.com/v1/users/11124066204",
        "id": "11124066204",
        "images": [
            {
                "height": null,
                "url": "https://scontent-ams2-1.xx.fbcdn.net/v/t1.6435-1/69809582_10102088511738144_5412754542196424704_n.jpg?stp=c0.0.320.320a_dst-jpg_p320x320&_nc_cat=104&ccb=1-7&_nc_sid=0c64ff&_nc_ohc=uxmfdDkbS_YAX9AmJ3H&_nc_ht=scontent-ams2-1.xx&edm=AP4hL3IEAAAA&oh=00_AfArHPzppyUooSmM8EjW_yeJ9plpPJTh3QKEV2MInSStfw&oe=64395EB9",
                "width": null
            }
        ],
        "type": "user",
        "uri": "spotify:user:11124066204"
    };
}
# [1.2.0](https://github.com/spotify/spotify-web-api-ts-sdk/compare/v1.1.2...v1.2.0) (2024-01-17)


### Bug Fixes

* **.releaserc:** add default plugins ([01317ac](https://github.com/spotify/spotify-web-api-ts-sdk/commit/01317ac5703340c7683a283a41647aa710a4cd4a))


### Features

* **.github/workflows:** replace npm-publish workflow with release workflow ([6b6ce72](https://github.com/spotify/spotify-web-api-ts-sdk/commit/6b6ce721e6be031fa27410fc2b78e4f8b45c4c4b))
* **semantic-release:** install semantic release ([39a06d7](https://github.com/spotify/spotify-web-api-ts-sdk/commit/39a06d7fcf8ab0d0de1a5b01dbc576c8ef0bd49b))
